# Pista original de 30 s para la intro de Autopilot (síntesis pura, sin samples).
import numpy as np, wave, sys
SR = 44100; DUR = 30.0; BPM = 100; BEAT = 60 / BPM
t = np.arange(int(SR * DUR)) / SR
L = np.zeros_like(t); R = np.zeros_like(t)
rng = np.random.default_rng(7)

def hz(n): return 440 * 2 ** ((n - 69) / 12)
def env(n, a, r):
    e = np.ones(n); a = min(n, int(a * SR)); r = min(n, int(r * SR))
    if a: e[:a] = np.linspace(0, 1, a)
    if r: e[-r:] *= np.linspace(1, 0, r)
    return e
def add(sig, start, gain=1.0, pan=0.0):
    i = int(start * SR); j = min(len(t), i + len(sig)); s = sig[: j - i] * gain
    L[i:j] += s * (1 - pan) ** 0.5; R[i:j] += s * (1 + pan) ** 0.5

# Acordes Am – F – C – G (2 compases cada uno), pad cálido desafinado
chords = [[57, 60, 64, 69], [53, 57, 60, 65], [48, 55, 60, 64], [55, 59, 62, 67]]
bar = BEAT * 4; seg = bar * 2
for k in range(int(DUR // seg) + 1):
    st = k * seg
    if st >= DUR: break
    ln = min(seg + 1.5, DUR - st); n = int(ln * SR); tt = np.arange(n) / SR
    for note in chords[k % 4]:
        for d, p in ((-0.08, -0.6), (0.08, 0.6)):
            f = hz(note + d)
            w = np.sin(2*np.pi*f*tt) + 0.3*np.sin(2*np.pi*2*f*tt) + 0.12*np.sin(2*np.pi*3*f*tt)
            add(w * env(n, 1.2, 1.5), st, 0.035, p)
    # bajo
    f = hz(chords[k % 4][0] - 12)
    add(np.sin(2*np.pi*f*tt) * env(n, 0.05, 1.0), st, 0.16)

# Arpegio tipo campana desde 6 s
arp_t = 6.0
while arp_t < 27:
    k = int(arp_t // seg) % 4; idx = int((arp_t - 6) / (BEAT / 2)) % 4
    note = chords[k][idx] + 12; n = int(1.2 * SR); tt = np.arange(n) / SR
    w = np.sin(2*np.pi*hz(note)*tt) * np.exp(-tt * 4) + 0.2*np.sin(2*np.pi*hz(note)*3.01*tt)*np.exp(-tt*9)
    add(w, arp_t, 0.05 * min(1, (arp_t - 6) / 4), 0.4 if idx % 2 else -0.4)
    arp_t += BEAT / 2

# Bombo suave desde 12 s, caja/palma desde 18 s, hats desde 12 s
def kick():
    n = int(0.45 * SR); tt = np.arange(n) / SR
    f = 50 + 90 * np.exp(-tt * 30)
    return np.sin(2*np.pi*np.cumsum(f)/SR) * np.exp(-tt * 7)
def clap():
    n = int(0.25 * SR); tt = np.arange(n) / SR
    return rng.standard_normal(n) * np.exp(-tt * 18) * 0.5
def hat():
    n = int(0.06 * SR); x = rng.standard_normal(n); x = np.diff(x, prepend=0)
    return x * np.exp(-np.arange(n) / SR * 70)
b = 12.0
while b < 26.4:
    add(kick(), b, 0.5)
    if b >= 18 and int(round((b - 12) / BEAT)) % 2 == 1: add(clap(), b, 0.18)
    add(hat(), b + BEAT / 2, 0.06, 0.3)
    b += BEAT

# Subida de ruido 22–24 s y golpe final en 24 s
n = int(2.4 * SR); tt = np.arange(n) / SR
riser = rng.standard_normal(n) * (tt / tt[-1]) ** 2
riser = np.convolve(riser, np.ones(8) / 8, mode="same")
add(riser, 21.6, 0.08)
hit_n = int(5.5 * SR); tt = np.arange(hit_n) / SR
hit = kick()[: hit_n]
hit = np.pad(hit, (0, hit_n - len(hit)))
for note in [45, 57, 64, 69, 72]:
    hit += 0.25 * np.sin(2*np.pi*hz(note)*tt) * np.exp(-tt * 0.7)
add(hit, 24.0, 0.35)

# Fundido de entrada/salida, eco sencillo y normalizado
for ch in (L, R):
    d = int(BEAT * 0.75 * SR); ch[d:] += 0.22 * ch[:-d].copy()
fade = np.ones_like(t); fi = int(1.5 * SR); fo = int(2.5 * SR)
fade[:fi] = np.linspace(0, 1, fi); fade[-fo:] = np.linspace(1, 0, fo)
st = np.stack([L * fade, R * fade], 1)
st = np.tanh(st * 1.4); st /= np.abs(st).max() / 0.89
with wave.open(sys.argv[1], "wb") as w:
    w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR)
    w.writeframes((st * 32767).astype(np.int16).tobytes())
