import { loadFont } from "@remotion/google-fonts/Inter";
import {
  AbsoluteFill,
  Audio,
  Composition,
  Easing,
  Img,
  interpolate,
  Sequence,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";

const { fontFamily } = loadFont("normal", { weights: ["400", "600", "700", "800"] });

// Tokens de .claude/design/tokens.md
const BLACK = "#000";
const GOLD = "hsl(43 61% 60%)";
const MUTED = "hsl(0 0% 64%)";
const IOS = Easing.bezier(0.32, 0.72, 0, 1);
const FPS = 30;
const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;

const useSpring = (delay = 0, damping = 18) => {
  const f = useCurrentFrame();
  const { fps } = useVideoConfig();
  return spring({ frame: f - delay, fps, config: { damping, mass: 0.9 } });
};
const useFadeOut = (len: number, d = 12) => {
  const f = useCurrentFrame();
  return interpolate(f, [len - d, len], [1, 0], clamp);
};

export const Halo: React.FC<{ size?: number; x?: string; y?: string; o?: number }> = ({ size = 1200, x = "50%", y = "50%", o = 1 }) => (
  <div
    style={{
      position: "absolute",
      left: x,
      top: y,
      width: size,
      height: size,
      transform: "translate(-50%, -50%)",
      borderRadius: "50%",
      opacity: o,
      background: "radial-gradient(closest-side, hsl(43 61% 60% / 0.16), transparent)",
    }}
  />
);

export const Phone: React.FC<{ src: string; h?: number; style?: React.CSSProperties }> = ({ src, h = 860, style }) => (
  <div
    style={{
      height: h,
      width: (h * 738) / 1645 + 24,
      padding: 12,
      borderRadius: h * 0.075,
      background: "linear-gradient(145deg, hsl(0 0% 22%), hsl(0 0% 7%))",
      boxShadow: "0 60px 120px rgba(0,0,0,0.7)",
      ...style,
    }}
  >
    <Img src={staticFile(src)} style={{ width: "100%", height: "100%", borderRadius: h * 0.065, objectFit: "cover", display: "block" }} />
  </div>
);

// Titular que entra palabra a palabra con desenfoque
export const Kinetic: React.FC<{ text: string; delay?: number; size?: number; gold?: boolean; align?: "left" | "center" | "right" }> = ({
  text,
  delay = 0,
  size = 120,
  gold,
  align = "left",
}) => {
  const f = useCurrentFrame();
  return (
    <div style={{ fontSize: size, fontWeight: 800, letterSpacing: "-0.045em", lineHeight: 1.0, textAlign: align, color: gold ? GOLD : "white" }}>
      {text.split(" ").map((w, i) => {
        const p = interpolate(f - delay - i * 4, [0, 16], [0, 1], { ...clamp, easing: IOS });
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              marginRight: "0.24em",
              opacity: p,
              filter: `blur(${(1 - p) * 14}px)`,
              transform: `translateY(${(1 - p) * 50}px)`,
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

export const Kicker: React.FC<{ text: string; delay?: number }> = ({ text, delay = 0 }) => {
  const f = useCurrentFrame();
  const p = interpolate(f - delay, [0, 18], [0, 1], { ...clamp, easing: IOS });
  return (
    <div style={{ fontSize: 34, fontWeight: 600, color: MUTED, opacity: p, transform: `translateX(${(1 - p) * -30}px)`, marginBottom: 22 }}>
      {text}
    </div>
  );
};

// 1 · Logo real
const LogoReveal: React.FC<{ len: number }> = ({ len }) => {
  const f = useCurrentFrame();
  const s = useSpring(8, 12);
  const out = useFadeOut(len);
  const letters = "Autopilot".split("");
  const halo = interpolate(f, [0, 40], [0, 1], clamp);
  const ring = interpolate(f, [8, 50], [0, 1], { ...clamp, easing: IOS });
  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", opacity: out, transform: `scale(${interpolate(f, [0, len], [1, 1.06])})` }}>
      <Halo size={700 + halo * 700} o={halo} />
      <div
        style={{
          position: "absolute",
          width: 300 + ring * 700,
          height: 300 + ring * 700,
          borderRadius: "50%",
          border: `2px solid hsl(43 61% 60% / ${0.35 * (1 - ring)})`,
        }}
      />
      <div style={{ transform: `scale(${s}) rotate(${(1 - s) * -12}deg)`, filter: `drop-shadow(0 0 ${40 * s}px hsl(43 61% 60% / 0.25))` }}>
        <Img src={staticFile("autopilot-logo.png")} style={{ width: 240, height: 240, borderRadius: 54 }} />
      </div>
      <div style={{ marginTop: 44, fontSize: 104, fontWeight: 800, letterSpacing: "-0.045em", color: "white", display: "flex" }}>
        {letters.map((l, i) => {
          const p = interpolate(f - 30 - i * 2.5, [0, 14], [0, 1], { ...clamp, easing: IOS });
          return (
            <span key={i} style={{ opacity: p, transform: `translateY(${(1 - p) * 40}px)`, filter: `blur(${(1 - p) * 10}px)` }}>
              {l}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

// 1b · Gancho: pregunta desde el fotograma 0 sobre cortes rápidos de pantallas reales
const Hook: React.FC<{ len: number }> = ({ len }) => {
  const f = useCurrentFrame();
  const out = useFadeOut(len, 8);
  const shots = ["registro.jpg", "progreso.jpg", "nutricion.jpg", "entrenar.jpg", "hoy.jpg"];
  const cut = Math.floor(f / 7) % shots.length;
  const punch = 1.25 - (f % 7) * 0.02;
  return (
    <AbsoluteFill style={{ opacity: out, alignItems: "center", justifyContent: "center" }}>
      <div style={{ position: "absolute", transform: `scale(${punch}) rotate(${cut % 2 ? 4 : -4}deg)`, opacity: 0.5 }}>
        <Phone src={shots[cut]} h={1000} />
      </div>
      <AbsoluteFill style={{ background: "radial-gradient(closest-side, rgba(0,0,0,0.2), #000)" }} />
      <div style={{ position: "relative", textAlign: "center", padding: "0 120px" }}>
        <Kinetic text="¿Y si tu entreno" size={140} align="center" delay={0} />
        <Kinetic text="se planificara solo?" size={140} align="center" delay={16} gold />
      </div>
    </AbsoluteFill>
  );
};

// 2 · Pantalla Hoy en 3D
const Today: React.FC<{ len: number }> = ({ len }) => {
  const f = useCurrentFrame();
  const s = useSpring(0, 16);
  const out = useFadeOut(len);
  const rot = interpolate(f, [0, len], [-28, 4]);
  const drift = interpolate(f, [0, len], [60, -60]);
  return (
    <AbsoluteFill style={{ opacity: out, flexDirection: "row", alignItems: "center", padding: "0 150px", perspective: 1800, transform: `scale(${interpolate(f, [0, len], [1, 1.08])})` }}>
      <Halo size={1300} x="70%" />
      <div style={{ flex: 1 }}>
        <Kicker text="Cada día, lo que toca." delay={10} />
        <Kinetic text="Tu entreno," delay={14} />
        <Kinetic text="tu comida," delay={22} />
        <Kinetic text="tu progreso." delay={30} gold />
      </div>
      <div style={{ transform: `translateY(${(1 - s) * 500 + drift}px) rotateY(${rot}deg) rotateX(6deg)`, opacity: s }}>
        <Phone src="hoy.jpg" h={900} />
      </div>
    </AbsoluteFill>
  );
};

// 3 · Tres funciones, tres pantallas
const Feature: React.FC<{ len: number; kicker: string; title: string; gold?: boolean; src: string; side: 1 | -1 }> = ({
  len,
  kicker,
  title,
  gold,
  src,
  side,
}) => {
  const f = useCurrentFrame();
  const s = useSpring(0, 15);
  const out = useFadeOut(len, 8);
  const x = (1 - s) * 900 * side;
  const tilt = interpolate(f, [0, len], [10 * side, 2 * side]);
  const zoom = interpolate(f, [0, len], [1, 1.05]);
  return (
    <AbsoluteFill style={{ opacity: out, alignItems: "center", justifyContent: "center", perspective: 1800 }}>
      <Halo size={1100} x={side === 1 ? "68%" : "32%"} />
      <div
        style={{
          position: "absolute",
          [side === 1 ? "left" : "right"]: 150,
          width: 820,
          textAlign: side === 1 ? "left" : "right",
        }}
      >
        <Kicker text={kicker} delay={6} />
        <Kinetic text={title} delay={10} size={130} gold={gold} align={side === 1 ? "left" : "right"} />
      </div>
      <div
        style={{
          position: "absolute",
          [side === 1 ? "right" : "left"]: 260,
          transform: `translateX(${x}px) rotateY(${-tilt}deg) scale(${zoom})`,
        }}
      >
        <Phone src={src} h={920} />
      </div>
    </AbsoluteFill>
  );
};

// 4 · Abanico de pantallas + Mac
const Everywhere: React.FC<{ len: number }> = ({ len }) => {
  const f = useCurrentFrame();
  const out = useFadeOut(len);
  const shots = ["entrenar.jpg", "nutricion.jpg", "progreso.jpg"];
  const mac = useSpring(4, 18);
  const pan = interpolate(f, [0, len], [120, -120]);
  return (
    <AbsoluteFill style={{ opacity: out, alignItems: "center", perspective: 2000, transform: `scale(${interpolate(f, [0, len], [1, 1.1])})` }}>
      <Halo size={1500} y="58%" />
      <div style={{ marginTop: 60, textAlign: "center", position: "relative", zIndex: 10 }}>
        <Kinetic text="iPhone, Mac, Android y web." size={92} align="center" delay={4} />
      </div>
      <div style={{ position: "absolute", bottom: -40, left: "50%", transform: `translateX(calc(-50% + ${pan}px))`, display: "flex", alignItems: "flex-end" }}>
        <div style={{ transform: `translateY(${(1 - mac) * 400}px)`, opacity: mac, marginRight: -140, zIndex: 0 }}>
          <div style={{ width: 1180, padding: 14, borderRadius: 30, background: "linear-gradient(145deg, hsl(0 0% 22%), hsl(0 0% 7%))", boxShadow: "0 60px 120px rgba(0,0,0,0.7)" }}>
            <Img src={staticFile("mac-hoy.jpg")} style={{ width: "100%", borderRadius: 18, display: "block" }} />
          </div>
        </div>
        {shots.map((src, i) => {
          const s = spring({ frame: f - 8 - i * 6, fps: FPS, config: { damping: 16 } });
          const r = (i - 1) * 8;
          return (
            <div key={src} style={{ zIndex: 1 + i, marginLeft: i ? -90 : 0, transform: `translateY(${(1 - s) * 600 + Math.abs(i - 1) * 50}px) rotate(${r * s}deg)` }}>
              <Phone src={src} h={820} />
            </div>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};

// 5 · Cierre
// Firma de marca (.claude/design/marca.md): geometría única de brand-mark.tsx, viewBox 10 8 80 80.
const BRAND_A = "M50 10L88 86H70L50 44L30 86H12Z";
const BRAND_BOLT = "M52 55L44 70H49.5L47 81L56 65H50.5Z";
const BRAND_EASE = Easing.bezier(0.34, 1.56, 0.64, 1);

// La «A» sube desde abajo con el rebote de marca; luego el rayo cae y late.
// En imágenes fijas (still) se pinta ya terminada: el fotograma 0 de la animación es invisible.
export const BrandMark: React.FC<{ size: number; still?: boolean }> = ({ size, still }) => {
  const frame = useCurrentFrame();
  const f = still ? 60 : frame;
  const a = interpolate(f, [0, 14], [0, 1], { ...clamp, easing: BRAND_EASE });
  const reveal = interpolate(f, [0, 14], [100, 0], { ...clamp, easing: IOS });
  const bolt = interpolate(f, [14, 22], [0, 1], { ...clamp, easing: BRAND_EASE });
  const beat = f > 22 ? 1 + 0.08 * Math.max(0, Math.sin(((f - 22) / 18) * Math.PI)) ** 8 : 1;
  const flash = interpolate(f, [14, 18, 30], [0, 1, 0], clamp);
  return (
    <svg viewBox="10 8 80 80" width={size} height={size} style={{ overflow: "visible", filter: `drop-shadow(0 0 ${30 + flash * 50}px hsl(43 61% 60% / ${0.25 + flash * 0.35}))` }}>
      <defs>
        <linearGradient id="gold" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#E3C46F" />
          <stop offset="1" stopColor="#D2AD58" />
        </linearGradient>
      </defs>
      <path d={BRAND_A} fill="url(#gold)" style={{ clipPath: `inset(${reveal}% 0 0 0)`, transform: `translateY(${(1 - a) * 6}px)` }} />
      <path
        d={BRAND_BOLT}
        fill="url(#gold)"
        style={{ transformBox: "fill-box", transformOrigin: "center", opacity: bolt, transform: `translateY(${(1 - bolt) * -14}px) scale(${beat})` }}
      />
    </svg>
  );
};

const Outro: React.FC = () => {
  const f = useCurrentFrame();
  const s = useSpring(0, 11);
  const cta = useSpring(34, 14);
  const pulse = 1 + Math.sin(f / 8) * 0.012 * cta;
  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", transform: `scale(${interpolate(f, [0, 180], [1.06, 1], clamp)})` }}>
      <Halo size={900 + s * 600} />
      <BrandMark size={300} />
      <div style={{ marginTop: 24, fontSize: 72, fontWeight: 800, letterSpacing: "-0.045em", color: "white", opacity: s }}>Autopilot</div>
      <div style={{ marginTop: 40 }}>
        <Kinetic text="Entrena con plan." size={92} align="center" delay={12} />
        <Kinetic text="Mira cómo progresas." size={92} align="center" delay={20} gold />
      </div>
      <div
        style={{
          marginTop: 56,
          padding: "24px 64px",
          borderRadius: 999,
          background: GOLD,
          color: BLACK,
          fontSize: 40,
          fontWeight: 700,
          opacity: cta,
          transform: `translateY(${(1 - cta) * 30}px) scale(${pulse})`,
        }}
      >
        Empieza gratis
      </div>
    </AbsoluteFill>
  );
};

const T = { logo: 90, today: 150, feat: 90, every: 210 };

// Locución (ElevenLabs): [fotograma de inicio, duración en fotogramas]
const VO: [number, number][] = [
  [2, 106],
  [108, 175],
  [286, 58],
  [348, 74],
  [426, 86],
  [516, 98],
  [720, 178],
];

export const AutopilotIntro: React.FC = () => {
  const { durationInFrames } = useVideoConfig();
  let at = 0;
  const next = (n: number) => {
    const from = at;
    at += n;
    return from;
  };
  return (
    <AbsoluteFill style={{ background: BLACK, fontFamily, overflow: "hidden" }}>
      <Audio src={staticFile("music.wav")} volume={(f) => (VO.some(([at, len]) => f >= at - 6 && f < at + len + 6) ? 0.16 : 0.75)} />
      {VO.map(([at], i) => (
        <Sequence key={i} from={at} name={`Voz ${i + 1}`}>
          <Audio src={staticFile(`vo/${i + 1}.mp3`)} volume={1.6} />
        </Sequence>
      ))}
      <Sequence from={next(T.logo)} durationInFrames={T.logo} name="Logo">
        <Hook len={T.logo} />
      </Sequence>
      <Sequence from={next(T.today)} durationInFrames={T.today} name="Hoy">
        <Today len={T.today} />
      </Sequence>
      <Sequence from={next(T.feat)} durationInFrames={T.feat} name="Entrenar">
        <Feature len={T.feat} kicker="A tu objetivo y material." title="Entrena con plan." src="entrenar.jpg" side={1} />
      </Sequence>
      <Sequence from={next(T.feat)} durationInFrames={T.feat} name="Registro">
        <Feature len={T.feat} kicker="Peso, reps y descanso." title="Registra cada serie." src="registro.jpg" side={-1} />
      </Sequence>
      <Sequence from={next(T.feat)} durationInFrames={T.feat} name="Progreso">
        <Feature len={T.feat} kicker="Historial, récords y volumen." title="Mira cómo progresas." gold src="progreso.jpg" side={1} />
      </Sequence>
      <Sequence from={next(T.every)} durationInFrames={T.every} name="Plataformas">
        <Everywhere len={T.every} />
      </Sequence>
      <Sequence from={at} durationInFrames={durationInFrames - at} name="Cierre">
        <Outro />
      </Sequence>
    </AbsoluteFill>
  );
};

export const MyComposition = () => (
  <Composition id="AutopilotIntro" component={AutopilotIntro} durationInFrames={30 * FPS} fps={FPS} width={1920} height={1080} />
);
