import { loadFont } from "@remotion/google-fonts/Inter";
import { AbsoluteFill, Still } from "remotion";
import { BrandMark, Halo, Phone } from "./Composition";

const { fontFamily } = loadFont("normal", { weights: ["600", "800"] });
const GOLD = "hsl(43 61% 60%)";
const MUTED = "hsl(0 0% 64%)";

// Banner 2560×1440. Zona segura (se ve en móvil): 1546×423 en el centro.
const Banner: React.FC = () => (
  <AbsoluteFill style={{ background: "#000", fontFamily, overflow: "hidden" }}>
    <Halo size={1800} />
    {/* Pantallas reales a los lados: solo se ven en ordenador y TV */}
    <div style={{ position: "absolute", left: 60, top: 330, transform: "rotate(-8deg)", opacity: 0.9 }}><Phone src="hoy.jpg" h={900} /></div>
    <div style={{ position: "absolute", right: 60, top: 330, transform: "rotate(8deg)", opacity: 0.9 }}><Phone src="progreso.jpg" h={900} /></div>
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", textAlign: "center" }}>
      <div style={{ fontSize: 104, fontWeight: 800, letterSpacing: "-0.045em", lineHeight: 1.02, color: "white" }}>
        Entrena con plan.<br /><span style={{ color: GOLD }}>Mira cómo progresas.</span>
      </div>
      <div style={{ marginTop: 34, fontSize: 46, fontWeight: 600, color: MUTED }}>
        autopilotplan.com · Gratis, sin tarjeta
      </div>
    </AbsoluteFill>
  </AbsoluteFill>
);

const Avatar: React.FC = () => (
  <AbsoluteFill style={{ background: "#000", alignItems: "center", justifyContent: "center" }}>
    <Halo size={900} />
    <BrandMark size={520} still />
  </AbsoluteFill>
);

// Marca de agua de los vídeos (150×150, fondo transparente)
const Watermark: React.FC = () => (
  <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
    <BrandMark size={130} still />
  </AbsoluteFill>
);

export const YouTubeStills = () => (
  <>
    <Still id="youtube-banner" width={2560} height={1440} component={Banner} />
    <Still id="youtube-avatar" width={800} height={800} component={Avatar} />
    <Still id="youtube-marca-agua" width={150} height={150} component={Watermark} />
  </>
);
