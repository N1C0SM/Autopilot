import { MyComposition } from "./Composition";
import { VerticalComposition } from "./Vertical";
import { PostStills } from "./Posts";
import { ReelCompositions } from "./Reels";
import { HowItWorksComposition } from "./HowItWorks";
import { HighlightStills } from "./Highlights";
import { YouTubeStills } from "./YouTube";

export const RemotionRoot: React.FC = () => {
  return (
    <>
      <MyComposition />
      <VerticalComposition />
      <PostStills />
      <ReelCompositions />
      <HowItWorksComposition />
      <HighlightStills />
      <YouTubeStills />
    </>
  );
};
