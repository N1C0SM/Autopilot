import { loadFont } from "@remotion/google-fonts/Inter";
import {
  AbsoluteFill,
  Audio,
  Composition,
  Easing,
  Img,
  interpolate,
  Sequence,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { BrandMark, Halo, Kinetic, Phone } from "./Composition";

const { fontFamily } = loadFont("normal", { weights: ["600", "700", "800"] });

const GOLD = "hsl(43 61% 60%)";
const IOS = Easing.bezier(0.32, 0.72, 0, 1);
const clamp = { extrapolateLeft: "clamp", extrapolateRight: "clamp" } as const;
const FPS = 30;

// [inicio, duración] en fotogramas; texto = subtítulo de lo que dice la voz
const VO: { at: number; len: number; text: string; gold?: string }[] = [
  { at: 2, len: 91, text: "¿Qué nota le pondría una IA a tu físico?", gold: "tu físico?" },
  { at: 94, len: 98, text: "Súbele una foto… y en segundos lo sabes.", gold: "en segundos" },
  { at: 214, len: 82, text: "Y Autopilot te monta el plan para mejorarla.", gold: "el plan" },
  { at: 336, len: 103, text: "Entra en autopilotplan.com. Es gratis.", gold: "Es gratis." },
];

// Subtítulo grande, palabra a palabra, con la palabra clave en dorado
export const Caption: React.FC<{ text: string; gold?: string }> = ({ text, gold }) => {
  const f = useCurrentFrame();
  const goldWords = new Set((gold ?? "").split(" "));
  return (
    <div style={{ position: "absolute", bottom: 300, left: 70, right: 70, textAlign: "center", fontSize: 76, fontWeight: 800, letterSpacing: "-0.04em", lineHeight: 1.08 }}>
      {text.split(" ").map((w, i) => {
        const p = interpolate(f - i * 3.5, [0, 8], [0, 1], { ...clamp, easing: IOS });
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              marginRight: "0.22em",
              color: goldWords.has(w) ? GOLD : "white",
              opacity: p,
              transform: `translateY(${(1 - p) * 30}px) scale(${0.9 + p * 0.1})`,
              textShadow: "0 4px 30px rgba(0,0,0,0.8)",
            }}
          >
            {w}
          </span>
        );
      })}
    </div>
  );
};

// 1 · Gancho: la foto entra y una línea dorada la escanea
const Hook: React.FC = () => {
  const f = useCurrentFrame();
  const s = spring({ frame: f, fps: FPS, config: { damping: 14 } });
  const line = interpolate(f % 40, [0, 40], [0, 100]);
  return (
    <AbsoluteFill style={{ alignItems: "center", paddingTop: 140 }}>
      <Halo size={1300} y="35%" />
      <div style={{ position: "relative", width: 880, height: 890, borderRadius: 28, overflow: "hidden", transform: `scale(${0.8 + s * 0.2})`, opacity: s }}>
        <Img src={staticFile("foto.jpg")} style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${interpolate(f, [0, 90], [1.08, 1])})` }} />
        <div style={{ position: "absolute", left: 0, right: 0, top: `${line}%`, height: 4, background: GOLD, boxShadow: `0 0 40px 10px hsl(43 61% 60% / 0.45)` }} />
        <div style={{ position: "absolute", inset: 0, background: `linear-gradient(to bottom, transparent ${line - 12}%, hsl(43 61% 60% / 0.12) ${line}%, transparent ${line + 0.5}%)` }} />
      </div>
    </AbsoluteFill>
  );
};

// 2 · Resultado real del scan en el teléfono, con la nota contando
const Result: React.FC = () => {
  const f = useCurrentFrame();
  const s = spring({ frame: f, fps: FPS, config: { damping: 15 } });
  const score = interpolate(f, [10, 45], [0, 5.2], { ...clamp, easing: IOS });
  return (
    <AbsoluteFill style={{ alignItems: "center", paddingTop: 150, perspective: 2000 }}>
      <Halo size={1400} y="40%" />
      <div style={{ transform: `translateY(${(1 - s) * 900}px) rotateX(${(1 - s) * 25}deg) scale(${interpolate(f, [0, 120], [1, 1.06])})` }}>
        <Phone src="scan.jpg" h={1250} />
      </div>
      <div
        style={{
          position: "absolute",
          top: 230,
          right: 90,
          padding: "18px 30px",
          borderRadius: 999,
          background: GOLD,
          color: "#000",
          fontSize: 52,
          fontWeight: 800,
          fontVariantNumeric: "tabular-nums",
          opacity: interpolate(f, [8, 16], [0, 1], clamp),
          transform: `scale(${spring({ frame: f - 8, fps: FPS, config: { damping: 10 } })})`,
        }}
      >
        {score.toFixed(1).replace(".", ",")} / 10
      </div>
    </AbsoluteFill>
  );
};

// 3 · El plan: tres pantallas reales que se suceden con golpe
const Plan: React.FC = () => {
  const f = useCurrentFrame();
  const shots = ["entrenar.jpg", "registro.jpg", "progreso.jpg"];
  return (
    <AbsoluteFill style={{ alignItems: "center", paddingTop: 150 }}>
      <Halo size={1400} y="40%" />
      {shots.map((src, i) => {
        const local = f - i * 40;
        const s = spring({ frame: local, fps: FPS, config: { damping: 15 } });
        const visible = local >= 0 && (i === shots.length - 1 || local < 46);
        if (!visible) return null;
        return (
          <div key={src} style={{ position: "absolute", top: 150, transform: `translateX(${(1 - s) * 900}px) rotate(${(1 - s) * 8}deg)` }}>
            <Phone src={src} h={1250} />
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

// 4 · Cierre: la «A», la web y «Gratis. Sin tarjeta.»
export const End: React.FC = () => {
  const f = useCurrentFrame();
  const url = interpolate(f, [20, 34], [0, 1], { ...clamp, easing: IOS });
  return (
    <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", paddingBottom: 380 }}>
      <Halo size={1500} y="40%" />
      <BrandMark size={380} />
      <div style={{ marginTop: 50 }}>
        <Kinetic text="autopilotplan.com" size={86} align="center" delay={14} />
      </div>
      <div style={{ marginTop: 40, padding: "26px 60px", borderRadius: 999, background: GOLD, color: "#000", fontSize: 50, fontWeight: 800, opacity: url, transform: `translateY(${(1 - url) * 30}px)` }}>
        Gratis · Sin tarjeta
      </div>
    </AbsoluteFill>
  );
};

export const AutopilotVertical: React.FC = () => {
  const { durationInFrames } = useVideoConfig();
  return (
    <AbsoluteFill style={{ background: "#000", fontFamily, overflow: "hidden" }}>
      {/* La pista empieza en el segundo 13 para que su golpe caiga en el cierre (11 s) */}
      <Audio src={staticFile("music.wav")} startFrom={13 * FPS} volume={(f) => (VO.some((v) => f >= v.at - 6 && f < v.at + v.len + 6) ? 0.16 : 0.75)} />
      <Sequence durationInFrames={92} name="Gancho"><Hook /></Sequence>
      <Sequence from={92} durationInFrames={120} name="Resultado"><Result /></Sequence>
      <Sequence from={212} durationInFrames={118} name="Plan"><Plan /></Sequence>
      <Sequence from={330} durationInFrames={durationInFrames - 330} name="Cierre"><End /></Sequence>
      {VO.map((v, i) => (
        <Sequence key={i} from={v.at} durationInFrames={v.len + 4} name={`Voz ${i + 1}`}>
          <Audio src={staticFile(`vov/${i + 1}.mp3`)} volume={1.6} />
          <Caption text={v.text} gold={v.gold} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};

export const VerticalComposition = () => (
  <Composition id="AutopilotVertical" component={AutopilotVertical} durationInFrames={15 * FPS} fps={FPS} width={1080} height={1920} />
);
