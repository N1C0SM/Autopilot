import { loadFont } from "@remotion/google-fonts/Inter";
import { AbsoluteFill, Audio, Composition, Img, interpolate, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { Halo, Phone } from "./Composition";
import { Caption, End } from "./Vertical";

const { fontFamily } = loadFont("normal", { weights: ["600", "700", "800"] });
const FPS = 30;

// Reel «POV»: el problema en 3 s, la app en pantallas reales y el cierre gratis.
const VO: { at: number; len: number; text: string; gold?: string }[] = [
  { at: 2, len: 87, text: "Llegas al gym… y no sabes qué hacer.", gold: "qué hacer." },
  { at: 98, len: 116, text: "Abres Autopilot y tu entreno de hoy ya está listo.", gold: "ya está listo." },
  { at: 224, len: 60, text: "Apuntas cada serie…", gold: "cada serie…" },
  { at: 292, len: 60, text: "y ves cómo vas mejorando.", gold: "mejorando." },
  { at: 366, len: 96, text: "Entra en autopilotplan.com. Es gratis.", gold: "Es gratis." },
];

const Pov: React.FC = () => {
  const f = useCurrentFrame();
  const shake = Math.sin(f / 2.2) * interpolate(f, [30, 60], [0, 6], { extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <AbsoluteFill>
      <Img src={staticFile("gym.png")} style={{ width: "100%", height: "100%", objectFit: "cover", transform: `scale(${interpolate(f, [0, 95], [1.25, 1.1])}) translateX(${shake}px)`, filter: "brightness(0.55)" }} />
      <AbsoluteFill style={{ background: "linear-gradient(to bottom, rgba(0,0,0,0.5), transparent 30%, transparent 55%, #000 90%)" }} />
      <div style={{ position: "absolute", top: 180, left: 0, right: 0, textAlign: "center", fontFamily, fontSize: 110, fontWeight: 800, letterSpacing: "-0.04em", color: "white" }}>POV</div>
    </AbsoluteFill>
  );
};

const Screen: React.FC<{ src: string; from?: number }> = ({ src, from = 1 }) => {
  const f = useCurrentFrame();
  const s = spring({ frame: f, fps: FPS, config: { damping: 15 } });
  return (
    <AbsoluteFill style={{ alignItems: "center", paddingTop: 150 }}>
      <Halo size={1400} y="40%" />
      <div style={{ transform: `translateX(${(1 - s) * 900 * from}px) rotate(${(1 - s) * 8 * from}deg) scale(${interpolate(f, [0, 120], [1, 1.05])})` }}>
        <Phone src={src} h={1250} />
      </div>
    </AbsoluteFill>
  );
};

export const AutopilotPov: React.FC = () => {
  const { durationInFrames } = useVideoConfig();
  return (
    <AbsoluteFill style={{ background: "#000", fontFamily, overflow: "hidden" }}>
      {/* Golpe de la música (seg. 24 de la pista) justo en el cierre (12 s) */}
      <Audio src={staticFile("music.wav")} startFrom={12 * FPS} volume={(f) => (VO.some((v) => f >= v.at - 6 && f < v.at + v.len + 6) ? 0.16 : 0.75)} />
      <Sequence durationInFrames={95} name="POV"><Pov /></Sequence>
      <Sequence from={95} durationInFrames={125} name="Hoy"><Screen src="hoy.jpg" /></Sequence>
      <Sequence from={220} durationInFrames={70} name="Registro"><Screen src="registro.jpg" from={-1} /></Sequence>
      <Sequence from={290} durationInFrames={70} name="Progreso"><Screen src="progreso.jpg" /></Sequence>
      <Sequence from={360} durationInFrames={durationInFrames - 360} name="Cierre"><End /></Sequence>
      {VO.map((v, i) => (
        <Sequence key={i} from={v.at} durationInFrames={v.len + 4} name={`Voz ${i + 1}`}>
          <Audio src={staticFile(`vop/${i + 1}.mp3`)} volume={1.6} />
          <Caption text={v.text} gold={v.gold} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};

export const ReelCompositions = () => (
  <Composition id="ReelPov" component={AutopilotPov} durationInFrames={16 * FPS} fps={FPS} width={1080} height={1920} />
);
