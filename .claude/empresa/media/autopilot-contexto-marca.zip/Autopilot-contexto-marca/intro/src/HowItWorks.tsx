import { loadFont } from "@remotion/google-fonts/Inter";
import { loadFont as loadFigure } from "@remotion/google-fonts/BigShoulders";
import { AbsoluteFill, Audio, Composition, interpolate, Sequence, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { Halo, Kinetic, Phone } from "./Composition";
import { Caption, End } from "./Vertical";

const { fontFamily } = loadFont("normal", { weights: ["600", "700", "800"] });
const { fontFamily: figure } = loadFigure("normal", { weights: ["800"] });
const GOLD = "hsl(43 61% 60%)";
const FPS = 30;

// Reel para fijar en el perfil: los 5 pasos de la app con pantallas reales.
const VO: { at: number; len: number; text: string; gold?: string }[] = [
  { at: 4, len: 55, text: "Así funciona Autopilot.", gold: "Autopilot." },
  { at: 74, len: 98, text: "Te haces el scan y la IA te pone nota.", gold: "te pone nota." },
  { at: 184, len: 156, text: "Te monta la rutina para tu objetivo, tus días y tu material.", gold: "la rutina" },
  { at: 350, len: 101, text: "Apuntas cada serie mientras entrenas.", gold: "cada serie" },
  { at: 460, len: 89, text: "Calorías y macros para tu objetivo.", gold: "Calorías y macros" },
  { at: 560, len: 110, text: "Y ves cómo progresas, semana a semana.", gold: "progresas," },
  { at: 680, len: 118, text: "Todo esto, gratis. En autopilotplan.com.", gold: "gratis." },
];

const STEPS = [
  { from: 70, to: 180, n: "1", label: "Scan", src: "scan.jpg" },
  { from: 180, to: 345, n: "2", label: "Rutina", src: "hoy.jpg" },
  { from: 345, to: 455, n: "3", label: "Registro", src: "registro.jpg" },
  { from: 455, to: 555, n: "4", label: "Nutrición", src: "nutricion.jpg" },
  { from: 555, to: 675, n: "5", label: "Progreso", src: "progreso.jpg" },
];

const Title: React.FC = () => (
  <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", paddingBottom: 200 }}>
    <Halo size={1300} y="40%" />
    <Kinetic text="Así funciona" size={130} align="center" delay={2} />
    <Kinetic text="Autopilot" size={150} align="center" delay={10} gold />
  </AbsoluteFill>
);

const Step: React.FC<{ n: string; label: string; src: string; dir: 1 | -1 }> = ({ n, label, src, dir }) => {
  const f = useCurrentFrame();
  const s = spring({ frame: f, fps: FPS, config: { damping: 15 } });
  const b = spring({ frame: f - 6, fps: FPS, config: { damping: 11 } });
  return (
    <AbsoluteFill style={{ alignItems: "center", paddingTop: 230 }}>
      <Halo size={1400} y="42%" />
      <div style={{ position: "absolute", top: 90, left: 70, display: "flex", alignItems: "baseline", gap: 20, transform: `scale(${b})`, transformOrigin: "left center" }}>
        <span style={{ fontFamily: figure, fontSize: 150, fontWeight: 800, color: GOLD, lineHeight: 1 }}>{n}</span>
        <span style={{ fontFamily, fontSize: 60, fontWeight: 800, color: "white", letterSpacing: "-0.03em" }}>{label}</span>
      </div>
      <div style={{ transform: `translateX(${(1 - s) * 900 * dir}px) rotate(${(1 - s) * 8 * dir}deg) scale(${interpolate(f, [0, 160], [1, 1.05])})` }}>
        <Phone src={src} h={1120} />
      </div>
    </AbsoluteFill>
  );
};

export const HowItWorks: React.FC = () => {
  const { durationInFrames } = useVideoConfig();
  return (
    <AbsoluteFill style={{ background: "#000", fontFamily, overflow: "hidden" }}>
      {/* Golpe de la pista (seg. 24) en el cierre (22,5 s) */}
      <Audio src={staticFile("music.wav")} startFrom={45} volume={(f) => (VO.some((v) => f >= v.at - 6 && f < v.at + v.len + 6) ? 0.16 : 0.7)} />
      <Sequence durationInFrames={70} name="Título"><Title /></Sequence>
      {STEPS.map((st, i) => (
        <Sequence key={st.n} from={st.from} durationInFrames={st.to - st.from} name={`Paso ${st.n}`}>
          <Step n={st.n} label={st.label} src={st.src} dir={i % 2 ? -1 : 1} />
        </Sequence>
      ))}
      <Sequence from={675} durationInFrames={durationInFrames - 675} name="Cierre"><End /></Sequence>
      {VO.map((v, i) => (
        <Sequence key={i} from={v.at} durationInFrames={v.len + 4} name={`Voz ${i + 1}`}>
          <Audio src={staticFile(`voc/${i + 1}.mp3`)} volume={1.6} />
          {i > 0 && <Caption text={v.text} gold={v.gold} />}
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};

export const HowItWorksComposition = () => (
  <Composition id="ComoFunciona" component={HowItWorks} durationInFrames={27 * FPS} fps={FPS} width={1080} height={1920} />
);
