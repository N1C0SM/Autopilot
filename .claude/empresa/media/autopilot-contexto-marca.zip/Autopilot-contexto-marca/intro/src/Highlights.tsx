import { loadFont } from "@remotion/google-fonts/Inter";
import { loadFont as loadFigure } from "@remotion/google-fonts/BigShoulders";
import { AbsoluteFill, Img, Still, staticFile } from "remotion";
import { BrandMark, Halo, Phone } from "./Composition";

const { fontFamily } = loadFont("normal", { weights: ["500", "600", "700", "800"] });
const { fontFamily: figure } = loadFigure("normal", { weights: ["800"] });
const GOLD = "hsl(43 61% 60%)";
const MUTED = "hsl(0 0% 64%)";
const CARD = "hsl(0 0% 9%)";

// Portadas de destacadas: icono dorado en el centro (Instagram las recorta en círculo).
const ICONS: Record<string, React.ReactNode> = {
  como: <path d="M38 28 L76 50 L38 72 Z" fill={GOLD} />,
  scan: (
    <g fill="none" stroke={GOLD} strokeWidth={6} strokeLinecap="round">
      <path d="M22 38 V24 H36 M64 24 H78 V38 M78 62 V76 H64 M36 76 H22 V62" />
      <path d="M30 50 H70" />
    </g>
  ),
  gratis: <path d="M28 52 L44 68 L74 34" fill="none" stroke={GOLD} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" />,
};

const Cover: React.FC<{ icon: string }> = ({ icon }) => (
  <AbsoluteFill style={{ background: "#000", alignItems: "center", justifyContent: "center" }}>
    <Halo size={1100} />
    <div style={{ width: 560, height: 560, borderRadius: "50%", background: CARD, display: "flex", alignItems: "center", justifyContent: "center" }}>
      <svg viewBox="0 0 100 100" width={300} height={300}>{ICONS[icon]}</svg>
    </div>
  </AbsoluteFill>
);

type Story = { kicker?: string; title: string; gold?: string; body?: string; list?: string[]; phone?: string; photo?: string; cta?: string };

const Title: React.FC<{ text: string; gold?: string; size: number }> = ({ text, gold, size }) => {
  const i = gold ? text.indexOf(gold) : -1;
  return (
    <div style={{ fontSize: size, fontWeight: 800, letterSpacing: "-0.045em", lineHeight: 1.02, color: "white" }}>
      {i < 0 ? text : (<>{text.slice(0, i)}<span style={{ color: GOLD }}>{gold}</span>{text.slice(i + gold!.length)}</>)}
    </div>
  );
};

// Historia 9:16 con zona segura arriba y abajo (la interfaz de Instagram tapa ~250 px)
const StoryView: React.FC<{ s: Story }> = ({ s }) => (
  <AbsoluteFill style={{ background: "#000", fontFamily, color: "white", overflow: "hidden" }}>
    <Halo size={1500} y={s.phone || s.photo ? "70%" : "40%"} />
    {s.cta ? (
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", padding: 90, textAlign: "center" }}>
        <BrandMark size={320} still />
        <div style={{ marginTop: 60 }}><Title text={s.title} gold={s.gold} size={96} /></div>
        {s.body && <div style={{ marginTop: 30, fontSize: 44, fontWeight: 500, color: MUTED, lineHeight: 1.3 }}>{s.body}</div>}
        <div style={{ marginTop: 60, padding: "30px 70px", borderRadius: 999, background: GOLD, color: "#000", fontSize: 50, fontWeight: 800 }}>{s.cta}</div>
        <div style={{ marginTop: 30, fontSize: 38, fontWeight: 600, color: MUTED }}>Enlace en la bio</div>
      </AbsoluteFill>
    ) : (
      <>
        <div style={{ position: "absolute", top: 280, left: 90, right: 90 }}>
          {s.kicker && <div style={{ fontSize: 42, fontWeight: 600, color: MUTED, marginBottom: 26 }}>{s.kicker}</div>}
          <Title text={s.title} gold={s.gold} size={s.phone || s.photo ? 100 : 120} />
          {s.body && <div style={{ marginTop: 34, fontSize: 46, fontWeight: 500, lineHeight: 1.3, color: "hsl(0 0% 80%)" }}>{s.body}</div>}
          {s.list && (
            <div style={{ marginTop: 56, display: "flex", flexDirection: "column", gap: 34 }}>
              {s.list.map((t, i) => (
                <div key={t} style={{ display: "flex", gap: 30, alignItems: "baseline", fontSize: 48, fontWeight: 600, lineHeight: 1.25 }}>
                  <span style={{ fontFamily: figure, fontSize: 64, fontWeight: 800, color: GOLD, width: 44, flexShrink: 0 }}>{i + 1}</span>
                  {t}
                </div>
              ))}
            </div>
          )}
        </div>
        {s.phone && (
          <div style={{ position: "absolute", left: "50%", bottom: -250, transform: "translateX(-50%) rotate(-4deg)" }}>
            <Phone src={s.phone} h={1250} />
          </div>
        )}
        {s.photo && (
          <div style={{ position: "absolute", left: 90, right: 90, bottom: 280, height: 980, borderRadius: 28, overflow: "hidden" }}>
            <Img src={staticFile(s.photo)} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "50% 30%" }} />
            <div style={{ position: "absolute", left: 0, right: 0, top: "40%", height: 4, background: GOLD, boxShadow: "0 0 40px 10px hsl(43 61% 60% / 0.45)" }} />
          </div>
        )}
      </>
    )}
  </AbsoluteFill>
);

export const STORIES: Record<string, Story[]> = {
  scan: [
    { kicker: "Scan con IA · gratis", title: "¿Qué nota le pondría una IA a tu físico?", gold: "tu físico?", photo: "foto.jpg" },
    { kicker: "Cómo hacerte la foto", title: "Así sale bien.", gold: "bien.", list: ["Móvil a 2–3 m, a la altura del ombligo", "Cuerpo entero, de frente", "Luz natural, sin contraluz", "Si quieres, otra de espalda"] },
    { kicker: "Lo que te da gratis", title: "Tu nota, tu punto débil y 2 mejoras.", gold: "punto débil", phone: "scan.jpg" },
    { cta: "Hacerme el scan", title: "autopilotplan.com/scan", gold: "/scan", body: "Menos de un minuto. Sin registro." },
  ],
  gratis: [
    { kicker: "¿Es gratis?", title: "Sí. Sin tarjeta.", gold: "Sin tarjeta." },
    { kicker: "Lo que tienes gratis", title: "Por 0 €:", gold: "0 €", list: ["Rutina según tu objetivo, días y material", "Registro de series, reps y kg", "Historial, peso y récords", "Calorías y macros", "Scan básico de tu físico"] },
    { cta: "Empezar gratis", title: "autopilotplan.com", gold: "autopilotplan.com", body: "Si un día quieres más, existe Plus. Pero no hace falta para empezar." },
  ],
};

export const HighlightStills = () => (
  <>
    {Object.keys(ICONS).map((k) => (
      <Still key={k} id={`portada-${k}`} width={1080} height={1920} component={() => <Cover icon={k} />} />
    ))}
    {Object.entries(STORIES).flatMap(([name, list]) =>
      list.map((s, i) => <Still key={`${name}-${i}`} id={`historia-${name}-${i + 1}`} width={1080} height={1920} component={() => <StoryView s={s} />} />),
    )}
  </>
);
