import { loadFont } from "@remotion/google-fonts/Inter";
import { loadFont as loadFigure } from "@remotion/google-fonts/BigShoulders";
import { AbsoluteFill, Img, Still, staticFile } from "remotion";
import { BrandMark, Halo, Phone } from "./Composition";

const { fontFamily } = loadFont("normal", { weights: ["500", "600", "700", "800"] });
const { fontFamily: figure } = loadFigure("normal", { weights: ["800"] });

const GOLD = "hsl(43 61% 60%)";
const MUTED = "hsl(0 0% 64%)";
const CARD = "hsl(0 0% 9%)";

type Slide = {
  kicker?: string;
  title: string;
  gold?: string; // fragmento del título en dorado
  body?: string;
  phone?: string;
  photo?: string;
  rows?: [string, string][];
  list?: string[];
  number?: string;
  cta?: boolean;
};

// Titular con un fragmento en dorado (la palabra clave, nunca todo)
const Title: React.FC<{ text: string; gold?: string; size: number; align?: "left" | "center" }> = ({ text, gold, size, align = "left" }) => {
  const i = gold ? text.indexOf(gold) : -1;
  return (
    <div style={{ fontSize: size, fontWeight: 800, letterSpacing: "-0.045em", lineHeight: 1.0, color: "white", textAlign: align }}>
      {i < 0 ? text : (
        <>
          {text.slice(0, i)}
          <span style={{ color: GOLD }}>{gold}</span>
          {text.slice(i + gold!.length)}
        </>
      )}
    </div>
  );
};

const SlideView: React.FC<{ slide: Slide; index: number; total: number }> = ({ slide, index, total }) => {
  const visual = slide.phone || slide.photo;
  return (
    <AbsoluteFill style={{ background: "#000", fontFamily, color: "white", overflow: "hidden" }}>
      <Halo size={1400} x={visual ? "50%" : "70%"} y={visual ? "78%" : "30%"} />
      {/* Cabecera: progreso del carrusel; la «A» solo en la portada y el cierre */}
      <div style={{ position: "absolute", top: 64, left: 80, right: 80, display: "flex", gap: 8 }}>
        {Array.from({ length: total }).map((_, i) => (
          <div key={i} style={{ flex: 1, height: 5, borderRadius: 99, background: i <= index ? GOLD : "hsl(0 0% 18%)" }} />
        ))}
      </div>

      {slide.cta ? (
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", padding: 80 }}>
          <BrandMark size={300} still />
          <div style={{ marginTop: 50 }}>
            <Title text={slide.title} gold={slide.gold} size={84} align="center" />
          </div>
          {slide.body && <div style={{ marginTop: 28, fontSize: 38, fontWeight: 500, color: MUTED, textAlign: "center", lineHeight: 1.3 }}>{slide.body}</div>}
          <div style={{ marginTop: 50, padding: "26px 60px", borderRadius: 999, background: GOLD, color: "#000", fontSize: 44, fontWeight: 800 }}>
            Gratis · Sin tarjeta
          </div>
          <div style={{ marginTop: 26, fontSize: 32, fontWeight: 600, color: MUTED }}>Enlace en la bio</div>
        </AbsoluteFill>
      ) : (
        <div
          style={
            visual
              ? { position: "absolute", top: 150, left: 80, right: 80 }
              : { position: "absolute", top: 100, bottom: 100, left: 80, right: 80, display: "flex", flexDirection: "column", justifyContent: "center" }
          }
        >
          {slide.number && (
            <div style={{ fontFamily: figure, fontSize: 200, fontWeight: 800, lineHeight: 0.9, color: GOLD, marginBottom: 20 }}>{slide.number}</div>
          )}
          {slide.kicker && <div style={{ fontSize: 36, fontWeight: 600, color: MUTED, marginBottom: 22 }}>{slide.kicker}</div>}
          <Title text={slide.title} gold={slide.gold} size={visual ? 88 : index === 0 ? 136 : 112} />
          {!visual && index === 0 && <div style={{ marginTop: 40, fontSize: 36, fontWeight: 600, color: MUTED }}>Desliza →</div>}
          {slide.body && <div style={{ marginTop: 30, fontSize: 40, fontWeight: 500, lineHeight: 1.32, color: "hsl(0 0% 80%)" }}>{slide.body}</div>}
          {slide.rows && (
            <div style={{ marginTop: 50, borderRadius: 28, background: CARD, padding: "8px 44px" }}>
              {slide.rows.map(([k, v], i) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "30px 0", borderBottom: i < slide.rows!.length - 1 ? "1px solid hsl(0 0% 16%)" : "none", fontSize: 40 }}>
                  <span style={{ color: MUTED, fontWeight: 500 }}>{k}</span>
                  <span style={{ fontWeight: 700 }}>{v}</span>
                </div>
              ))}
            </div>
          )}
          {slide.list && (
            <div style={{ marginTop: 44, display: "flex", flexDirection: "column", gap: 26 }}>
              {slide.list.map((t) => (
                <div key={t} style={{ display: "flex", gap: 22, alignItems: "flex-start", fontSize: 40, fontWeight: 600, lineHeight: 1.25 }}>
                  <div style={{ width: 18, height: 18, borderRadius: 99, background: GOLD, marginTop: 14, flexShrink: 0 }} />
                  {t}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {slide.phone && (
        <div style={{ position: "absolute", left: "50%", bottom: -360, transform: "translateX(-50%) rotate(-4deg)" }}>
          <Phone src={slide.phone} h={1100} />
        </div>
      )}
      {slide.photo && (
        <div style={{ position: "absolute", left: 80, right: 80, bottom: 80, height: 860, borderRadius: 28, overflow: "hidden" }}>
          <Img src={staticFile(slide.photo)} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "50% 30%" }} />
          <div style={{ position: "absolute", left: 0, right: 0, top: "38%", height: 4, background: GOLD, boxShadow: "0 0 40px 10px hsl(43 61% 60% / 0.45)" }} />
        </div>
      )}
    </AbsoluteFill>
  );
};

const CTA: Slide = { cta: true, title: "Pruébalo hoy en autopilotplan.com", gold: "autopilotplan.com" };

export const CAROUSELS: Record<string, Slide[]> = {
  scan: [
    { kicker: "Scan con IA · gratis", title: "¿Qué nota le pondría una IA a tu físico?", gold: "tu físico?", photo: "foto.jpg" },
    { kicker: "Cómo funciona", title: "Una foto. Menos de un minuto.", gold: "Menos de un minuto.", list: ["Foto de frente, con luz natural", "Si quieres, otra de espalda", "Sin registro para hacer el scan"] },
    { kicker: "Lo que te da gratis", title: "Tu nota, tu punto débil y 2 mejoras.", gold: "punto débil", phone: "scan.jpg" },
    { kicker: "Con Plus", title: "¿Quieres el análisis entero?", gold: "entero?", list: ["Composición corporal: % graso y masa magra", "Puntuación de cada grupo muscular", "Postura y proporciones", "Protocolo: series, calorías y ejercicios"] },
    { ...CTA, title: "Hazte el scan en autopilotplan.com", body: "Y guarda el resultado para comparar el siguiente." },
  ],
  plan: [
    { kicker: "Guarda esto", title: "Deja de improvisar en el gym.", gold: "improvisar" },
    { kicker: "Paso 1", title: "Dinos qué buscas.", gold: "qué buscas.", rows: [["Objetivo", "Ganar músculo"], ["Nivel", "Intermedio"], ["Días", "4 por semana"], ["Material", "Gimnasio"]] },
    { kicker: "Paso 2", title: "Abres la app y ya sabes qué toca.", gold: "qué toca.", phone: "hoy.jpg" },
    { kicker: "Paso 3", title: "Registra cada serie.", gold: "cada serie.", phone: "registro.jpg" },
    { kicker: "Paso 4", title: "Mira cómo progresas.", gold: "progresas.", phone: "progreso.jpg" },
    CTA,
  ],
  senales: [
    { kicker: "Si te pasa, no es falta de ganas", title: "3 señales de que tu entreno no progresa", gold: "no progresa" },
    { number: "1", title: "Levantas lo mismo cada semana.", gold: "lo mismo", body: "Sin sobrecarga progresiva el cuerpo no tiene motivo para cambiar. Sube reps o kilos poco a poco." },
    { number: "2", title: "No apuntas lo que haces.", gold: "No apuntas", body: "Si no sabes qué levantaste la semana pasada, no puedes saber si estás mejorando." },
    { number: "3", title: "Cada día improvisas.", gold: "improvisas.", body: "Sin un plan semanal, unos músculos se entrenan de más y otros se quedan atrás." },
    { kicker: "La solución", title: "Plan, registro y progreso en una app.", gold: "en una app.", phone: "registro.jpg" },
    CTA,
  ],
};

export const PostStills = () => (
  <>
    {Object.entries(CAROUSELS).flatMap(([name, slides]) =>
      slides.map((slide, i) => (
        <Still
          key={`${name}-${i}`}
          id={`carrusel-${name}-${i + 1}`}
          width={1080}
          height={1350}
          component={() => <SlideView slide={slide} index={i} total={slides.length} />}
        />
      )),
    )}
  </>
);
