# Autopilot — Identidad de marca y contenido

Objetivo: que la gente pruebe la app gratis (adopción primero, cobrar después). Solo planes Gratis y Plus; no anunciar Coach ni «tu entrenador».

## Visual
- Negro + dorado sobrio, tarjetas sin borde (22/28 px), botones en píldora, cifras grandes redondeadas.
- Fotos reales y pantallas reales de la app. Nada que parezca dibujo; estilo Apple Fitness / Hevy.
- Logo: la «A» con rayo (`intro/public/autopilot-logo.png`, `diseno/icono-final.png`).

## Voz y sonido
- Voz en off: ElevenLabs, voice ID `POqQLDHlrtcu15h0tbcz`, modelo `eleven_v3`. Tono entusiasta, convincente, cercano, en español.
- La API key NO va aquí: usar variable de entorno `ELEVENLABS_API_KEY`.
- Música sintetizada (`intro/music/compose.py` → `public/music.wav`).
- Movimiento premium y gancho viral en los 2 primeros segundos.

## Producción
- Vídeos en Remotion (`intro/`): `npm install`, `npx remotion studio`. Reutilizar composiciones existentes (Composition, Reels, Vertical, Posts, Highlights, HowItWorks, YouTube).
- Enlaces con UTM según `captacion/CAPTACION-UTM.md`.
- Referencia de estilo: `publicaciones-hechas/`.
- Redes: Instagram, TikTok, Threads, YouTube Shorts, Facebook (programadas en Metricool).
